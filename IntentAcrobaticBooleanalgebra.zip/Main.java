import android.content.Intent;
import android.os.bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;

class CholInfoActivity extends App CompatActivity {

  @Override
  protected void OnCreate(Bundle SavedInstancesState){
    super.onCreate(SavedInstancesState);
    setContentView(R.layout.activity_chol_info);
  }

class 

  public static void main(String[] args) {
    System.out.println("Hello world!");
  }
}

class 